package kr.or.multi.multiCommunity.dao;

public class MTDaoSqls {
	public static final String SELECT_ALL = "SELECT * FROM mt";
	
	//200415
	//그.. 뭐냐 primary key가 phone number인 건 이상하긴 하다만..
	public static final String DELETE_BY_PHONE_NUMBER = "DELETE FROM mt WHERE phone_number=:phoneNumber";
}
