package kr.or.multi.multiCommunity.service;

import java.util.List;

import kr.or.multi.multiCommunity.dto.Admin;
import kr.or.multi.multiCommunity.dto.ImgData;
import kr.or.multi.multiCommunity.dto.Locker;

public interface ImgDataService {
	public int updateMTInfoImg(ImgData imgdata);
	//	public Admin getAdminInfo(String area);
	public ImgData getImgName(String imgid);
	
	
	
	public List<ImgData> getImgDatas();
}
