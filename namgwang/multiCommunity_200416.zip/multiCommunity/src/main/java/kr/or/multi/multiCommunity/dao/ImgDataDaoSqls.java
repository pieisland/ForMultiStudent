package kr.or.multi.multiCommunity.dao;

public class ImgDataDaoSqls {
	
	//200416
	//잘 되려나. 여러 개 업데이트하기.
	public static final String UPDATE_MT_INFO_IMG = "UPDATE imgdata " 
			+ "SET img_name=:imgName, save_img_name=:saveImgName," + 
			"content_type=:contentType, file_length=:fileLength  WHERE img_id=:imgId";
	
	//이름만 쏙 빼우려구요
	public static final String SELECT_IMG_NAME_BY_IMG_ID = "select img_name from imgdata where img_id=:imgId";
	public static final String SELTEST = "select img_name from imgdata where img_id=:imgId";
	public static final String SELECT_ALL = "select * from imgdata";
	
	//public static final String SELECT_CONTENT_BY_AREA = "select content from admin where area = :area";
}
