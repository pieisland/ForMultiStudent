package kr.or.multi.multiCommunity.dao;

import static kr.or.multi.multiCommunity.dao.AdminDaoSqls.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import org.springframework.dao.EmptyResultDataAccessException;

import kr.or.multi.multiCommunity.dto.Admin;
import kr.or.multi.multiCommunity.dto.Locker;

@Repository
public class AdminDao {
	private NamedParameterJdbcTemplate jdbc;
	private SimpleJdbcInsert insertAction;
	
	private RowMapper<Admin> rowMapper = BeanPropertyRowMapper.newInstance(Admin.class);
	 
	
	public int update(Admin admin) {
		SqlParameterSource params = new BeanPropertySqlParameterSource(admin);
		return jdbc.update(UPDATE, params);
	}

	//따라했어여.. https://www.edwith.org/boostcourse-web/lecture/20661/
	public Admin getAdminInfo(String area) {
		try {
			Map<String,?> params = Collections.singletonMap("area", area);
			return jdbc.queryForObject(SELECT_CONTENT_BY_AREA, params, rowMapper);
		}catch(EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	/*public Role selectById(Integer id) {
		try {
			Map<String, ?> params = Collections.singletonMap("roleId", id);
			return jdbc.queryForObject(SELECT_BY_ROLE_ID, params, rowMapper);		
		}catch(EmptyResultDataAccessException e) {
			return null;
		}
	}*/	
	
	//사실 이건 왜 넣는지 모르겠다. 하지만 일단 만들어봄..
	 public AdminDao(DataSource dataSource) {
		this.jdbc = new NamedParameterJdbcTemplate(dataSource);
		this.insertAction = new SimpleJdbcInsert(dataSource)
	                .withTableName("admin");
	}
}
