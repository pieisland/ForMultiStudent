package kr.or.multi.multiCommunity.controller;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;
import java.io.File;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import kr.or.multi.multiCommunity.dto.Admin;
import kr.or.multi.multiCommunity.dto.Locker;
import kr.or.multi.multiCommunity.dto.MT;
import kr.or.multi.multiCommunity.dto.ImgData;
import kr.or.multi.multiCommunity.service.AdminService;
import kr.or.multi.multiCommunity.service.ImgDataService;
import kr.or.multi.multiCommunity.service.LockerService;
import kr.or.multi.multiCommunity.service.MTService;

@Controller
public class AdminController {
	@Autowired
	AdminService adminService;
	
	@Autowired
	LockerService lockerService;
	
	@Autowired
	MTService mtService;
	
	@Autowired
	ImgDataService imgDataService;
	
	//200416
	//언제인지 수정하는 부분.
	@PostMapping(path="/updateMTDay")
	public String updateMTDay(@ModelAttribute Admin admin) {
		adminService.updateAdmin(admin);
		
		return "redirect:/mt";
	}
	
	@PostMapping(path="/updateLockerDay")
	public String updateLockerDay(@ModelAttribute Admin admin) {
		adminService.updateAdmin(admin);
		
		return "redirect:/locker";
	}
	
	//200414 아 젠장~
	@PostMapping(path="/updatemt")
	public String updateMT(@ModelAttribute Admin admin) {
		adminService.updateAdmin(admin);
		//mtService.addMT(mt);
		//이래도 되는지 모르겠넹.
		///session.setAttribute("isMTApplyed", "true");

		return "redirect:/mt";
	}
		
	//관리자가 모든 등록된 사물함 정보를 삭제한다.
	@PostMapping(path="/deleteAllLocker")
	public String deleteAllLocker(ModelMap model)
	{
		//졸라 왜 안돼...
		List<Locker> list = lockerService.getLockers();//모든 locker를 가져온다.
		/*if(list.size() == 0) {
			model.addAttribute("list", list);
			return "locker";
		}*/
		
		//어차피 사이즈 0이면 이거 실행도 안되는걸 뭐..
		for(int i=0; i<list.size(); i++)
		{
			int lid = list.get(i).getLockerId();
			lockerService.deleteLocker(lid);
		}
		
		//다 없앤 상태의 모델을 다시 등록해줘야겠네 그러면...
		//하.. 그 GetMapping부분이 실행되는 게 아니라서 모델등록이 안되어서 그런 것 같습니다.. 네 젠장 뭐..
		//잘 모르겠긴 한데 ㅋㅋㅋ.. 대충 그런 느낌이다.
		//list = lockerService.getLockers();
		//model.addAttribute("list", list);
		
		return "redirect:/locker";	
	}
	
	@PostMapping(path="/deleteAllMT")
	public String deleteAllMT(ModelMap model) {
		
		List<MT> list = mtService.getMTs();//모든 locker를 가져온다.
		
		for(int i=0; i<list.size(); i++)
		{
			String phoneNumber = list.get(i).getPhoneNumber();
			mtService.deleteMT(phoneNumber);
		}
		
		return "redirect:/mt";	
	}
	
	//200416
	@PostMapping(path="/uploadMTimg")
	public String uploadMTimg(@RequestParam("file") MultipartFile file, 
			HttpServletRequest request, ModelMap model,
			@RequestParam(name="pastimg", required =true) String pastimg) {
		
		String path = "C:/Users/pieis/eclipse-workspace/multiCommunity/src/main/webapp/resources/images/";
		String path2= "C:/Users/pieis/eclipse-workspace/multiCommunity/src/main/webapp/";

//		request.get
		//model.
		
		//이미지를 올렸다면
		if(file.getOriginalFilename()!= null && file.getOriginalFilename()!="")
		{
			//먼저 이전에 올린 이미지를 삭제한다.
			//request.getAttribute아 안되길래 getParameter도 해봤는데 안되길래 결국 form에서 받아옴....
			//new File(path2 + (String)request.getParameter("mtimgpath")).delete();
			new File(path2 + pastimg).delete();	
			
			System.out.println(path2 + pastimg);
			System.out.println(path2 + pastimg);
			System.out.println(path2 + pastimg);
			System.out.println(path2 + pastimg);
			
			String id = "mtInfoImg";
			String name = file.getOriginalFilename();
			String savename = path + name; //굳이 쓸 일이 있을지는 모르겠음. 
			String contentType = file.getContentType();
			
			//아.. 나 integer로 만들었는데... 이거 바꿔야되나 그러면..
			//오류날지도 모름.. int형이라서.. ㅋ.. 몰라.
			long fileLength = file.getSize();
			ImgData imgdata = new ImgData();
			imgdata.setImgId(id);
			imgdata.setImgName(name);
			imgdata.setSaveImgName(savename);
			imgdata.setContentType(contentType);
			imgdata.setFileLength(fileLength);
			//파일 길이는 일단 null이다.. 젠장..
			imgDataService.updateMTInfoImg(imgdata);
			//값이 없는데 괜찮을까.. 지금이라도 long으로 바꿔??
			
			//imgDataService.updateMTInfoImg(imgdata);
			
			//System.out.println("파일 이름 : " + file.getOriginalFilename());
			//System.out.println("파일 크기 : " + file.getSize());
			//file.getContentTyle();
			//file.get
			
	        try(
	                // 맥일 경우 
	                //FileOutputStream fos = new FileOutputStream("/tmp/" + file.getOriginalFilename());
	                // 윈도우일 경우        		
	        		FileOutputStream fos = new FileOutputStream(savename);
	        		//FileOutputStream fos = new FileOutputStream("c:/tmp/" + file.getOriginalFilename());
	        		//FileOutputStream fos = new FileOutputStream(path + file.getOriginalFilename());
	        		//FileOutputStream fos = new FileOutputStream(path + "mtimg.jpg");
	        		InputStream is = file.getInputStream();
	        ){
	        	    int readCount = 0;
	        	    byte[] buffer = new byte[1024];
	            while((readCount = is.read(buffer)) != -1){
	                fos.write(buffer,0,readCount);
	            }
	        }catch(Exception ex){
	            throw new RuntimeException("file Save Error");
	        }
		}
		
		return "redirect:/mt";	
	}
}