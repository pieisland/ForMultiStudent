package kr.or.multi.multiCommunity.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import kr.or.multi.multiCommunity.dto.Admin;
import kr.or.multi.multiCommunity.service.AdminService;

@Controller
public class AdminController {
	@Autowired
	AdminService adminService;
	
	//200414 아 젠장~
	@PostMapping(path="/updatemt")
	public String updateMT(@ModelAttribute Admin admin) {
		adminService.updateAdmin(admin);
		//mtService.addMT(mt);
		//이래도 되는지 모르겠넹.
		///session.setAttribute("isMTApplyed", "true");

		return "redirect:/mt";
	}
}