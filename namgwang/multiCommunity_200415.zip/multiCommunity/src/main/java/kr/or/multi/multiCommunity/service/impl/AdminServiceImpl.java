package kr.or.multi.multiCommunity.service.impl;

//import java.util.Date;
//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.or.multi.multiCommunity.dao.AdminDao;
import kr.or.multi.multiCommunity.dto.Admin;
import kr.or.multi.multiCommunity.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService{
	@Autowired
	AdminDao adminDao;

	@Override
	@Transactional
	public int updateAdmin(Admin admin) {
		int ret = adminDao.update(admin);
		return ret;
	}
	
	//몰라 일단 string만 받는걸로 해뒀어요.

	@Override
	@Transactional
	public Admin getAdminInfo(String area) {
		return adminDao.getAdminInfo(area);
	}
}