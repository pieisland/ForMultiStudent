package kr.or.multi.multiCommunity.dao;

import static kr.or.multi.multiCommunity.dao.MTDaoSqls.SELECT_ALL;

import java.util.Collections;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import kr.or.multi.multiCommunity.dto.MT;
import kr.or.multi.multiCommunity.dto.Student;

@Repository
public class MTDao {
	 private NamedParameterJdbcTemplate jdbc;
	 private SimpleJdbcInsert insertAction;

	 private RowMapper<MT> rowMapper = BeanPropertyRowMapper.newInstance(MT.class);	 
	 
	 public MTDao(DataSource dataSource) {
		this.jdbc = new NamedParameterJdbcTemplate(dataSource);
		this.insertAction = new SimpleJdbcInsert(dataSource)
	                .withTableName("mt");
	}
	 
	public int insert(MT mt) {
		SqlParameterSource params = new BeanPropertySqlParameterSource(mt);
		return insertAction.execute(params);
	}	
	
	public List<MT> selectAll(){
		return jdbc.query(SELECT_ALL, Collections.emptyMap(), rowMapper);
	}
}
