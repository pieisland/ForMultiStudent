package kr.or.multi.multiCommunity.service;

import kr.or.multi.multiCommunity.dto.Admin;

public interface AdminService {
	//리턴타입이나 매개변수나 뭘 써야될 지 모르겠다 사실 ㅋㅋㅋ.
	public int updateAdmin(Admin admin);
	public Admin getAdminInfo(String area);
}