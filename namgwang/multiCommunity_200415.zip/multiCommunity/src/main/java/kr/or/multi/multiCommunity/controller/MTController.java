package kr.or.multi.multiCommunity.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.or.multi.multiCommunity.dto.Locker;
import kr.or.multi.multiCommunity.dto.MT;
import kr.or.multi.multiCommunity.service.MTService;

@Controller
public class MTController {
	@Autowired
	MTService mtService;
	
	//200411
	@PostMapping(path="/applyMT")
	public String applyMT(@ModelAttribute MT mt, HttpSession session) {
		//mtService.addMT(mt);
		//이래도 되는지 모르겠넹.
		///session.setAttribute("isMTApplyed", "true");

		return "redirect:/mt";
	}
}