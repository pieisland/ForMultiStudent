package kr.or.multi.multiCommunity.dao;

public class MTDaoSqls {
	public static final String SELECT_ALL = "SELECT * FROM mt";
}
