package kr.or.multi.multiCommunity.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.or.multi.multiCommunity.dao.MTDao;
import kr.or.multi.multiCommunity.dto.MT;
import kr.or.multi.multiCommunity.dto.Student;
import kr.or.multi.multiCommunity.service.MTService;

@Service
public class MTServiceImpl implements MTService{
	@Autowired
	MTDao mtDao;

	@Override
	@Transactional
	public MT addMT(MT mt) {
		mtDao.insert(mt);
		return mt;
	}
	
	@Override
	@Transactional
	public List<MT> getMTs() {
		List<MT> list = mtDao.selectAll();
		return list;
	}
}
