package kr.or.multi.multiCommunity.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.or.multi.multiCommunity.dao.LockerDao;
import kr.or.multi.multiCommunity.dto.Locker;
import kr.or.multi.multiCommunity.service.LockerService;

@Service
public class LockerServiceImpl implements LockerService{
	@Autowired
	LockerDao lockerDao;

	//transactional을 붙이면 read only. 아니면 false를 붙여준다.
	@Override
	@Transactional
	public List<Locker> getLockers() {
		List<Locker> list = lockerDao.selectAll();
		return list;
	}
	
	@Override
	@Transactional
	public Locker addLocker(Locker locker) {
		lockerDao.insert(locker);
		return locker;
	}
}
