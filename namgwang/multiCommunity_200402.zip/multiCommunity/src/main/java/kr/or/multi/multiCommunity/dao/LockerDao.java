package kr.or.multi.multiCommunity.dao;

import javax.sql.DataSource;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import kr.or.multi.multiCommunity.dto.Locker;

import static kr.or.multi.multiCommunity.dao.LockerDaoSqls.*;

@Repository
public class LockerDao {
	 private NamedParameterJdbcTemplate jdbc;
	 private SimpleJdbcInsert insertAction;

	 private RowMapper<Locker> rowMapper = BeanPropertyRowMapper.newInstance(Locker.class);
	 
	 public LockerDao(DataSource dataSource) {
		this.jdbc = new NamedParameterJdbcTemplate(dataSource);
		this.insertAction = new SimpleJdbcInsert(dataSource)
	                .withTableName("locker");
	}
	 
	public int insert(Locker locker) {
		SqlParameterSource params = new BeanPropertySqlParameterSource(locker);
		return insertAction.execute(params);
	}	
	
	public List<Locker> selectAll(){
		return jdbc.query(SELECT_ALL, Collections.emptyMap(), rowMapper);
	}	
}
