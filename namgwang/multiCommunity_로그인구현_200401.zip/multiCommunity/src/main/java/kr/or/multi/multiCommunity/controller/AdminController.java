package kr.or.multi.multiCommunity.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.or.multi.multiCommunity.dto.Student;

//이제 뭐.. AdminService ㅎ해야되나.. 이걸 다 만들어야되구나 ㅠㅠ
import kr.or.multi.multiCommunity.service.StudentService;

@Controller
public class AdminController {
	@Autowired
	StudentService studentService;//이건 나중에 adminService 만들고나서 고치겠습니당.
	
	//생각해보니까 href로 했는데 이게 되나요..?ㅋㅋㅋㅋㅋ
	//젠장맞을.. ㅋㅋㅋ
	@GetMapping(path="/loginform")
	public String loginform() {
		return "loginform";
	}
	//사실 href라서 이것 조차도 쓸모 없을 수가 있어요 ㅋㅋㅋㅋ
	//진짜루.. ㅋㅋㅋ 굳이 이걸 할 필요가 없을 수가 있어
	//대신 중요한 건 그거겠죠...
	
	
	/*public String locker(ModelMap model,
			   HttpServletRequest request,
			   HttpServletResponse response) {
		
		List<Student> list = studentService.getStudents();
		model.addAttribute("list", list);
		
		return "loginform";
	}*/
	
	//여기는 form action에 login이 적혀있는거잖아요.
	//맞으면 저장하는거고.. 세션에..
	//와 그럼.. 세션 뭐시기 하는것도 나중에 해야되는건가..?
	//뭔가 되게 많이 했었던 것 같은데 ㅋㅋㅋㅋ
	//나 진짜 기억 안남... ㅠㅠㅠ 으으으으.
	//로그인 정보가 일치하면 세션에 로그인 정보를 저장한다.
	@PostMapping(path="/login")
	//RequestParam에서 받은 passwd를 String passwd에 넣는다.
	public String login(@RequestParam(name="studentid", required =true) String studentid, 
			@RequestParam(name="studentname", required =true) String studentname,
			HttpSession session, RedirectAttributes redirectAttr,
			HttpServletRequest request,
			HttpServletResponse response) 
	{
		List<Student> list = studentService.getStudents();
		String sid;
		String sname;
		for(int i=0;i<list.size();i++)
		{
			sid = list.get(i).getStudentId();
			sname = list.get(i).getStudentName();
			/*System.out.println(studentid);
			System.out.println(studentname);
			System.out.println(sid);
			System.out.println(sname);*/
			
			if(studentid.equals(sid) && studentname.equals(sname)){
				//일치하는 하생이 있다는 것을 데이터베이스 내에서 확인했습니다.
				session.setAttribute("isAdmin", "true"); //로그인이 됐다는 것을 저장한 거에요.
				session.setAttribute("loginedStudentId", sid); //로그인한 학생의 아이디 정보에요.
				session.setAttribute("loginedStudentName", sname); //로그인한 학생의 이름이에요. 나중에 그러면
				//이름이 뭐 누구님 환영합니다 할 때 쓸 수 있지 않을까요?
				
				//일치하면 저장하고 바로 리턴하면 되겠죠?
				return "redirect:/locker";
			}
		}
		
		session.setAttribute("isAdmin", "false");
		//바로 리턴되지 않았으면 에러 메시지를 저장해두는걸로 하자.
		redirectAttr.addFlashAttribute("errorMessage", "등록된 사용자 정보가 없습니다.");	
		//그렇구나 모든 경우에 리턴을 해야되니까 그런 거였구나.
		return "redirect:/loginform";
		/*if("1234".equals(passwd)) //패스워드가 일치하면
		{
			//session에 isAdmin이라는 이름으로 true 값 넣어주기.
			session.setAttribute("isAdmin", "true");
		}else
		{
			//redirectAttr는 dispatcher servlet이 관리하는 flashmap에 값을 저장한다.
			//redirect는 요청이 두 번 오는 거.
			//forward는 요청 한 번.
			redirectAttr.addFlashAttribute("errorMessage", "암호가 틀렸습니다.");	
			return "redirect:/loginform";
		}
		return "redirect:/list";*/
	}
	
	//로그아웃하면 로그인 정보를 삭제한다.
	@GetMapping(path="/logout")
	public String login(HttpSession session) {
		session.removeAttribute("isAdmin");
		session.removeAttribute("loginedStudentId");
		session.removeAttribute("loginedStudentName");
		return "redirect:/index";//인덱스도 .. 등록해야되나?? 확인해보고 해야되면 등록하자. 근데 mvc 에 써둔게 있어서 될지도?
	}
}
