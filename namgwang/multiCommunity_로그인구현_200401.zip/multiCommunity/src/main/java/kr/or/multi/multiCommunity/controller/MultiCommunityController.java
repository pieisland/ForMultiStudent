package kr.or.multi.multiCommunity.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

import kr.or.multi.multiCommunity.dto.Locker;
import kr.or.multi.multiCommunity.service.LockerService;

@Controller
public class MultiCommunityController {

	@Autowired
	LockerService lockerService;
	
	@GetMapping(path="/index")
	public String index() {
		return "index";
	}
	
	@GetMapping(path="/locker")
	public String locker(ModelMap model,
			   HttpServletRequest request,
			   HttpServletResponse response) {
		
		List<Locker> list = lockerService.getLockers();
		model.addAttribute("list", list);
		
		return "locker";
	}
	
	
	@GetMapping(path="/myTest")
	public String myTest(ModelMap model,
			   HttpServletRequest request,
			   HttpServletResponse response) {
		List<Locker> list = lockerService.getLockers();
		model.addAttribute("list", list);
	
		return "myTest";
	}
	
	@GetMapping(path="/mypage")
	public String mypage() {
		return "mypage";
	}
}
