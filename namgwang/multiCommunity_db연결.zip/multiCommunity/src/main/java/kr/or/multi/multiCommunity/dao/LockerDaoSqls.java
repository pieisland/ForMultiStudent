package kr.or.multi.multiCommunity.dao;

//아직 어떤 거를 해야될지 모르겠어서 고치지 않았어요..

public class LockerDaoSqls {
	//public static final String SELECT_PAGING = "SELECT id, name, content, regdate FROM guestbook ORDER BY id DESC limit :start, :limit";
	//public static final String DELETE_BY_ID = "DELETE FROM guestbook WHERE id = :id";
	//public static final String SELECT_COUNT = "SELECT count(*) FROM guestbook";
	
	//대문자로 만들었어서 이렇게 했는데.. 흠..
	//데이터베이스 상에 있는 모든 LOCKER ID를 가져와서
	//음.. 
	//근데 이게 생각을 다르게할 수 있는게  값을 전부 다 가지고 있지만 가능한지 아닌지는 따로 저장돼있는거고
	//내가 생각을 했던 지정이 된 애만 가지고있는건데. 아무래도 전자를 생각한 것 같은데?
	//아이디 값은 모두 가지고 있을거고. 그 아이디 값 중에서 가능한 애, 불가능한 애를 가리는 게 AVAILAVLE인거고..
	//그래서 필요했던건가..?
	//그러면 지금 쓰는 SQL문은 필요가 없는데????
	//그러면 약간.. 음...TRUE인 것만 가져와요??
	//아니 근데 배열에 따로 저장해야되는 건. TRUE 값이 아니라 FALSE 값을 가지고 있는 애란 말이야..
	//뭐.. 음. 반대로 코딩을 해도 되기는 한데.
	//그러면 일단 FALSE 값을 가지는 애를 가져온다고 생각해볼게.
	//데이터베이스에 추가하는 건 다른 데서 만드나..?
	//아.. 음.. 아무튼 글 쓰는 걸 보면 될 것 같아 그 때는 CREATE로 하겠지 뭐. 지금은 일단은 ㅅ람들이 보기 위한거를 하겠습니당...
	public static final String SELECT_LOCKER_ID =  "SELECT locker_id FROM locker";
	
	//''를 쓰는건지 안쓰는건지는 모르겠어요..
	public static final String SELECT_UNAVAILABLE_LOCKER_ID = "SELECT locker_id FROM locker WHERE locker_available='false'";
	
	public static final String SELECT_ALL = "SELECT * FROM locker";
	
}
