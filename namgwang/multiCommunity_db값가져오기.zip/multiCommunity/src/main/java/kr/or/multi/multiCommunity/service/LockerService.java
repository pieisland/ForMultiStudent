package kr.or.multi.multiCommunity.service;

import java.util.List;
import kr.or.multi.multiCommunity.dto.Locker;

public interface LockerService {
	public List<Locker> getLockers();
}