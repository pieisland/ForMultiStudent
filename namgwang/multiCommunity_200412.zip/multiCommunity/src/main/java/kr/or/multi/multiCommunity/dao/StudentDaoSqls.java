package kr.or.multi.multiCommunity.dao;

public class StudentDaoSqls {
	public static final String SELECT_ALL = "SELECT student_id, student_name FROM student";
}