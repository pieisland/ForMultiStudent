package kr.or.multi.multiCommunity.service.impl;

//import java.util.Date;
//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.or.multi.multiCommunity.dao.AdminDao;
import kr.or.multi.multiCommunity.dto.Admin;
import kr.or.multi.multiCommunity.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService{
	@Autowired
	AdminDao adminDao;

	@Override
	@Transactional
	public int updateAdmin(Admin admin) { //글 정보 업데이트.
		int ret = adminDao.update(admin);
		return ret;
	}

	@Override
	@Transactional
	public Admin getAdminInfo(String area) { //글 정보를 area에 따라 가져옴.
		return adminDao.getAdminInfo(area);
	}
}