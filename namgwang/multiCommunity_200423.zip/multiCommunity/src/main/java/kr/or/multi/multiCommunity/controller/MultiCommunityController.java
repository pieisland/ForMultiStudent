package kr.or.multi.multiCommunity.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.or.multi.multiCommunity.dto.Admin;
import kr.or.multi.multiCommunity.dto.ImgData;
import kr.or.multi.multiCommunity.dto.Locker;
import kr.or.multi.multiCommunity.dto.MT;
import kr.or.multi.multiCommunity.service.AdminService;
import kr.or.multi.multiCommunity.service.ImgDataService;
import kr.or.multi.multiCommunity.service.LockerService;
import kr.or.multi.multiCommunity.service.MTService;

@Controller
public class MultiCommunityController {

	@Autowired
	LockerService lockerService;
	
	@Autowired
	MTService mtService;
	
	@Autowired
	AdminService adminService;
	
	@Autowired
	ImgDataService imgDataService;
	
	
	//index 페이지 보여줌.
	@GetMapping(path="/index")
	public String index() {
		return "index";
	}
	
	//사물함 신청 페이지 보여줌.
	@GetMapping(path="/locker")
	public String locker(ModelMap model,
			   HttpServletRequest request,
			   HttpServletResponse response) {
		
		List<Locker> list = lockerService.getLockers();
		model.addAttribute("list", list);
		
		//0405
		//GetMapping에서는 request의 setAttribute가 되는데 PostMapping에서 안된다는 걸 배웠다.
		
		//0416
		Admin ad = adminService.getAdminInfo("lockerDay");
		String content = (String)ad.getContent();
		model.addAttribute("lockerday", content);
		
		return "locker";
	}
	
	//MT신청페이지 보여줌.
	@GetMapping(path="/mt")
	public String mt(ModelMap model) {
		List<MT> list = mtService.getMTs();
		model.addAttribute("mtlist", list);
		
		Admin ad = adminService.getAdminInfo("mt");
		String content = (String)ad.getContent();
		model.addAttribute("mtinfo", content);
		
		ad = adminService.getAdminInfo("mtDay");//area 값이고
		content = (String)ad.getContent();
		model.addAttribute("mtDay", content);//모델로 새로 저장하는 값이고.
		
		//200416
		ImgData imgdata = imgDataService.getImgName("mtInfoImg");
		String tmp = (String)imgdata.getImgName();

		String mtimgpath = "resources/images/" + tmp;
		model.addAttribute("mtimgpath", mtimgpath);
		
		return "mt";
	}		
	
	//마이페이지 보여줌.
	@GetMapping(path="/mypage")
	public String mypage() {
		return "mypage";
	}
	
	//테스트한거라 신경 안써도 됨.
	@GetMapping(path="/myTest")
	public String myTest(ModelMap model,
			   HttpServletRequest request,
			   HttpServletResponse response) {
		List<Locker> list = lockerService.getLockers();
		model.addAttribute("list", list);
	
		return "myTest";
	}
}
