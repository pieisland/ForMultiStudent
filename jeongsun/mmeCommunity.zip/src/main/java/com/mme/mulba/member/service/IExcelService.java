package com.mme.mulba.member.service;

import javax.servlet.http.HttpServletResponse;

public interface IExcelService {
	public void getExcelDown(HttpServletResponse response);
}
