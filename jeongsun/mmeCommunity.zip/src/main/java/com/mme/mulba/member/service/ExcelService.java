package com.mme.mulba.member.service;

import java.awt.Color;
import java.awt.MultipleGradientPaint.ColorSpaceType;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.sl.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mme.mulba.member.dao.OperatingCostsContentDao;
import com.mme.mulba.member.dto.OperatingCostsContent;

@Service
public class ExcelService implements IExcelService{
	
	@Autowired
	OperatingCostsContentDao dao;
	
	@Autowired
	OperatingCostsService service;

	@Override
	public void getExcelDown(HttpServletResponse response) {
		// 게시판 목록조회
	    List<OperatingCostsContent> list = service.list();
        
        try{
        	
            //Excel Down 시작
            Workbook wb = new HSSFWorkbook();
            //시트생성
            Sheet sheet = wb.createSheet("학생회비");
            // 테이블 헤더용 스타일
    	    CellStyle headStyle = wb.createCellStyle();
            
            //행, 열, 열번호
            Row row = null;
            int rowNo = 0;
            Cell cell=null;
    
            // 가는 경계선을 가집니다.
    	    headStyle.setBorderTop(BorderStyle.THIN);
    	    headStyle.setBorderBottom(BorderStyle.THIN);
    	    headStyle.setBorderLeft(BorderStyle.THIN);
    	    headStyle.setBorderRight(BorderStyle.THIN);

    	    // 배경색은 노란색입니다.
    	    
    	    headStyle.setFillForegroundColor(HSSFColorPredefined.YELLOW.getIndex());
    	    headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
    	    
    	    // 데이터는 가운데 정렬합니다.
    	    headStyle.setAlignment(HorizontalAlignment.CENTER);
    	    headStyle.setVerticalAlignment(org.apache.poi.ss.usermodel.VerticalAlignment.CENTER);

    	    // 데이터용 경계 스타일 테두리만 지정
    	    CellStyle bodyStyle = wb.createCellStyle();
    	    bodyStyle.setBorderTop(BorderStyle.THIN);
    	    bodyStyle.setBorderBottom(BorderStyle.THIN);
    	    bodyStyle.setBorderLeft(BorderStyle.THIN);
    	    bodyStyle.setBorderRight(BorderStyle.THIN);
    	    bodyStyle.setAlignment(HorizontalAlignment.CENTER);
    	    bodyStyle.setVerticalAlignment(org.apache.poi.ss.usermodel.VerticalAlignment.CENTER);
    	    
    	    CellStyle bodyStyleMoney = wb.createCellStyle();
    	    DataFormat df = wb.createDataFormat();
    	    bodyStyleMoney.setDataFormat(df.getFormat("#,###"));
    	    bodyStyleMoney.setBorderTop(BorderStyle.THIN);
    	    bodyStyleMoney.setBorderBottom(BorderStyle.THIN);
    	    bodyStyleMoney.setBorderLeft(BorderStyle.THIN);
    	    bodyStyleMoney.setBorderRight(BorderStyle.THIN);
    	    bodyStyleMoney.setVerticalAlignment(org.apache.poi.ss.usermodel.VerticalAlignment.CENTER);
    	    
    	    CellStyle bodyStyleContent = wb.createCellStyle();
    	    bodyStyleContent.setBorderTop(BorderStyle.THIN);
    	    bodyStyleContent.setBorderBottom(BorderStyle.THIN);
    	    bodyStyleContent.setBorderLeft(BorderStyle.THIN);
    	    bodyStyleContent.setBorderRight(BorderStyle.THIN);
    	    bodyStyleContent.setAlignment(HorizontalAlignment.LEFT);
    	    bodyStyleContent.setVerticalAlignment(org.apache.poi.ss.usermodel.VerticalAlignment.CENTER);
    	    
    	    
    	    CellStyle[] eventStyle = new CellStyle[4];
    	    eventStyle[0] = wb.createCellStyle();
    	    eventStyle[0].setBorderTop(BorderStyle.THIN);
    	    eventStyle[0].setBorderBottom(BorderStyle.THIN);
    	    eventStyle[0].setBorderLeft(BorderStyle.THIN);
    	    eventStyle[0].setBorderRight(BorderStyle.THIN);
    	    eventStyle[0].setFillForegroundColor(IndexedColors.AQUA.getIndex());
    	    eventStyle[0].setFillPattern(FillPatternType.SOLID_FOREGROUND);
    	    eventStyle[0].setAlignment(HorizontalAlignment.CENTER);
    	    eventStyle[0].setVerticalAlignment(org.apache.poi.ss.usermodel.VerticalAlignment.CENTER);
    	    
    	    eventStyle[1] = wb.createCellStyle();
    	    eventStyle[1].setBorderTop(BorderStyle.THIN);
    	    eventStyle[1].setBorderBottom(BorderStyle.THIN);
    	    eventStyle[1].setBorderLeft(BorderStyle.THIN);
    	    eventStyle[1].setBorderRight(BorderStyle.THIN);
    	    eventStyle[1].setFillForegroundColor(IndexedColors.CORAL.getIndex());
    	    eventStyle[1].setFillPattern(FillPatternType.SOLID_FOREGROUND);
    	    eventStyle[1].setAlignment(HorizontalAlignment.CENTER);
    	    eventStyle[1].setVerticalAlignment(org.apache.poi.ss.usermodel.VerticalAlignment.CENTER);
    	    
    	    eventStyle[2] = wb.createCellStyle();
    	    eventStyle[2].setBorderTop(BorderStyle.THIN);
    	    eventStyle[2].setBorderBottom(BorderStyle.THIN);
    	    eventStyle[2].setBorderLeft(BorderStyle.THIN);
    	    eventStyle[2].setBorderRight(BorderStyle.THIN);
    	    eventStyle[2].setFillForegroundColor(IndexedColors.GOLD.getIndex());
    	    eventStyle[2].setFillPattern(FillPatternType.SOLID_FOREGROUND);
    	    eventStyle[2].setAlignment(HorizontalAlignment.CENTER);
    	    eventStyle[2].setVerticalAlignment(org.apache.poi.ss.usermodel.VerticalAlignment.CENTER);
    	    
    	    eventStyle[3] = wb.createCellStyle();
    	    eventStyle[3].setBorderTop(BorderStyle.THIN);
    	    eventStyle[3].setBorderBottom(BorderStyle.THIN);
    	    eventStyle[3].setBorderLeft(BorderStyle.THIN);
    	    eventStyle[3].setBorderRight(BorderStyle.THIN);
    	    eventStyle[3].setFillForegroundColor(IndexedColors.LAVENDER.getIndex());
    	    eventStyle[3].setFillPattern(FillPatternType.SOLID_FOREGROUND);
    	    eventStyle[3].setAlignment(HorizontalAlignment.CENTER);
    	    eventStyle[3].setVerticalAlignment(org.apache.poi.ss.usermodel.VerticalAlignment.CENTER);
    	    
    	 // 헤더 생성
    	    row = sheet.createRow(rowNo++);
    	    sheet.setColumnWidth(0, 2000);
    	    sheet.setColumnWidth(1, 4000);
    	    sheet.setColumnWidth(2, 6000);
    	    sheet.setColumnWidth(3, 8000);
    	    sheet.setColumnWidth(4, 4000);
    	    sheet.setColumnWidth(5, 4000);
    	    sheet.setColumnWidth(6, 4000);
    	    
    	    cell = row.createCell(0);
    	    cell.setCellStyle(headStyle);
    	    cell.setCellValue("번호");
    	    
    	    cell = row.createCell(1);
    	    cell.setCellStyle(headStyle);
    	    cell.setCellValue("날짜");
    	    
    	    cell = row.createCell(2);
    	    cell.setCellStyle(headStyle);
    	    cell.setCellValue("항목");
    	    
    	    cell = row.createCell(3);
    	    cell.setCellStyle(headStyle);
    	    cell.setCellValue("내용");
    	    
    	    cell = row.createCell(4);
    	    cell.setCellStyle(headStyle);
    	    cell.setCellValue("입금");
    	    
    	    cell = row.createCell(5);
    	    cell.setCellStyle(headStyle);
    	    cell.setCellValue("출금");
    	    
    	    cell = row.createCell(6);
    	    cell.setCellStyle(headStyle);
    	    cell.setCellValue("잔액");

    	    // 데이터 부분 생성

    	    int i=0;
    	    int index=-1;
    	    
    	    for(OperatingCostsContent vo : list) {
    	    	index++;
    	    	if(index>0) {
    	    		if(list.get(index-1).getEvent().equals(vo.getEvent())) {}
    	    		else {
    	    			//row = sheet.createRow(rowNo++);
    	    			i++;
    	    		}
    	    	}
    	        row = sheet.createRow(rowNo++);
    	        row.setHeight((short) 400);
    	        i = i%4;

    	        cell = row.createCell(0);
    	        cell.setCellStyle(bodyStyle);
    	        cell.setCellValue(vo.getRid());
    	        
    	        cell = row.createCell(1);
    	        cell.setCellStyle(bodyStyle);
    	        cell.setCellValue(vo.getEvent_date());
    	        
    	        cell = row.createCell(2);
    	        cell.setCellStyle(eventStyle[i]);
    	        cell.setCellValue(vo.getEvent());
    	        
    	        cell = row.createCell(3);
    	        cell.setCellStyle(bodyStyleContent);
    	        cell.setCellValue(vo.getContent());
    	        
    	        cell = row.createCell(4);
    	        cell.setCellStyle(bodyStyleMoney);
    	        cell.setCellValue(vo.getIncome());
    	        
    	        cell = row.createCell(5);
    	        cell.setCellStyle(bodyStyleMoney);
    	        cell.setCellValue(vo.getOutcome());
    	        
    	        cell = row.createCell(6);
    	        cell.setCellStyle(bodyStyleMoney);
    	        cell.setCellValue(vo.getBalance());
    	    }

    
            // 컨텐츠 타입과 파일명 지정
            response.setContentType("ms-vnd/excel");
            response.setHeader("Content-Disposition", "attachment;filename=test.xls");
 
            // 엑셀 출력
            wb.write(response.getOutputStream());
            wb.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
		
	}
	
}
