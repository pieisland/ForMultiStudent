package com.mme.mulba.member.service;

import java.util.List;

import com.mme.mulba.member.dto.OperatingCostsContent;

public interface IOperatingCostsService {
	//OperatingCostsContent occSearch(OperatingCostsContent occontent);
	OperatingCostsContent search(int id);
	List<OperatingCostsContent> list();
	void insert(OperatingCostsContent occ);
	void update(OperatingCostsContent occ);
}
