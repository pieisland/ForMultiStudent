package com.mme.mulba.member.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mme.mulba.member.dao.OperatingCostsContentDao;
import com.mme.mulba.member.dto.OperatingCostsContent;

@Service
public class OperatingCostsService implements IOperatingCostsService{
	
	@Autowired
	OperatingCostsContentDao dao;

	@Override
	public OperatingCostsContent search(int id) {
		//OperatingCostsContent occ = dao.ContentSelect(occontent);
		OperatingCostsContent occ = dao.ContentSelect(id);
		
		if (occ == null) {
			System.out.println("Search Fail!!");
		} else {
			System.out.println("Search Success!!");
		}
		
		return occ;
	}

	@Override
	public List<OperatingCostsContent> list() {
		return dao.list();
	}

	@Override
	public void insert(OperatingCostsContent occ) {
		dao.insert(occ);
	}

	@Override
	public void update(OperatingCostsContent occ) {
		dao.update(occ);
	}

}
