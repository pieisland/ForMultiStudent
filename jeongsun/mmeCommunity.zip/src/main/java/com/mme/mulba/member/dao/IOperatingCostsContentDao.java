package com.mme.mulba.member.dao;

import java.util.List;

import com.mme.mulba.member.dto.OperatingCostsContent;

public interface IOperatingCostsContentDao {
	int ContentInsert(OperatingCostsContent occ);
	//OperatingCostsContent ContentSelect(OperatingCostsContent occ);
	OperatingCostsContent ContentSelect(int id);
	int ContentUpdate(OperatingCostsContent occ);
	int ContentDelete(OperatingCostsContent occ);
	List<OperatingCostsContent> list();
	void insert(OperatingCostsContent occ);
	void update(OperatingCostsContent occ);
}
