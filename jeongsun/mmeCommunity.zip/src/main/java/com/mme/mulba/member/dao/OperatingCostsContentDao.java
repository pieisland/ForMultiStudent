package com.mme.mulba.member.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.mme.mulba.member.dto.OperatingCostsContent;

@Repository
public class OperatingCostsContentDao implements IOperatingCostsContentDao{
	
	private static String dburl = "jdbc:mysql://localhost:3306/mme?serverTimezone=Asia/Seoul";
	private static String dbuser = "adminuser";
	private static String dbpwd = "1111";

	private Connection conn = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;

	
	@Override
	public int ContentInsert(OperatingCostsContent occ) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public OperatingCostsContent ContentSelect(int id) {
		OperatingCostsContent occ = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(dburl, dbuser, dbpwd);
			String sql = "SELECT * FROM OperatingCosts WHERE rid=?;";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			
			while (rs.next()) {
				occ = new OperatingCostsContent();
				Integer rid = rs.getInt("rid");
				Integer prid = rs.getInt("prid");
				String event_date = rs.getString("event_date");
				event_date = event_date.substring(0, 10); //날짜 데이터를 자른다.
				String event = rs.getString("event");
				String content = rs.getString("content");
				int income = rs.getInt("income");
				int outcome = rs.getInt("outcome");
				int balance = rs.getInt("balance");
				String update_date = rs.getString("update_date");
				if(update_date==null) {
					update_date = "-";
				}
				else {
					System.out.println("substring : " + update_date);
					update_date = update_date.substring(0, 10);
				}

				occ.setRid(rid);
				occ.setPrid(prid);
				occ.setEvent_date(event_date);
				occ.setEvent(event);
				occ.setContent(content);
				occ.setIncome(income);
				occ.setOutcome(outcome);
				occ.setBalance(balance);
				occ.setUpdate_date(update_date);
			}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			try {
				if(rs != null) rs.close();
				if(ps != null) ps.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return occ;
	}

	@Override
	public int ContentUpdate(OperatingCostsContent occ) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int ContentDelete(OperatingCostsContent occ) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<OperatingCostsContent> list() {
		List<OperatingCostsContent> occlist = new ArrayList<OperatingCostsContent>();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(dburl, dbuser, dbpwd);
			String sql = "SELECT * FROM OperatingCosts;";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			
			while (rs.next()) {
				OperatingCostsContent occ = new OperatingCostsContent();
				Integer rid = rs.getInt("rid");
				Integer prid = rs.getInt("prid");
				String event_date = rs.getString("event_date");
				event_date = event_date.substring(0, 10);
				String event = rs.getString("event");
				String content = rs.getString("content");
				int income = rs.getInt("income");
				int outcome = rs.getInt("outcome");
				int balance = rs.getInt("balance");
				String update_date = rs.getString("update_date");
				if(update_date==null) {
					update_date = "-";
				}
				else {
					update_date = update_date.substring(0, 10);
				}

				occ.setRid(rid);
				occ.setPrid(prid);
				occ.setEvent_date(event_date);
				occ.setEvent(event);
				occ.setContent(content);
				occ.setIncome(income);
				occ.setOutcome(outcome);
				occ.setBalance(balance);
				occ.setUpdate_date(update_date);
				
				occlist.add(occ);
			}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(ps != null) ps.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return occlist;
	}

	@Override
	public void insert(OperatingCostsContent occ) {
		int cnt=0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(dburl, dbuser, dbpwd);
			String sql = "Insert INTO OperatingCosts VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, occ.getRid());
			ps.setInt(2, occ.getPrid());
			ps.setString(3, occ.getEvent_date());
			ps.setString(4, occ.getEvent());
			ps.setString(5, occ.getContent());
			ps.setInt(6,  occ.getIncome());
			ps.setInt(7,  occ.getOutcome());
			ps.setInt(8, occ.getBalance());
			if(occ.getUpdate_date()=="-") ps.setNull(9, java.sql.Types.NULL);
			else ps.setString(9, occ.getUpdate_date());
			
			cnt = ps.executeUpdate();	
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			try {
				if(rs != null) rs.close();
				if(ps != null) ps.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
	}

	@Override
	public void update(OperatingCostsContent occ) {
		System.out.println("here");
		int cnt=0;
		int balance=0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(dburl, dbuser, dbpwd);
			
			String sql = "SELECT balance FROM OperatingCosts WHERE rid=?;";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, occ.getRid()-1);
			rs = ps.executeQuery();
			
			while (rs.next()) {
				balance = rs.getInt("balance");
			}
			
			sql="";
			sql = "Update OperatingCosts SET event_date=?, event=?, content=?, income=?, outcome=?, balance=?, update_date=? WHERE rid=?;";
			ps = conn.prepareStatement(sql);
			ps.setString(1, occ.getEvent_date());
			ps.setString(2, occ.getEvent());
			ps.setString(3, occ.getContent());
			ps.setInt(4, occ.getIncome());
			ps.setInt(5, occ.getOutcome());
			ps.setInt(6, balance +occ.getIncome()-occ.getOutcome());
			ps.setString(7, occ.getUpdate_date());
			ps.setInt(8, occ.getRid());
			cnt = ps.executeUpdate();
		
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			try {
				if(rs != null) rs.close();
				if(ps != null) ps.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
	}
	
}
