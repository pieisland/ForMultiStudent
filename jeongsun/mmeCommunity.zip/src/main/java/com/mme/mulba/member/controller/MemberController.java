package com.mme.mulba.member.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mme.mulba.member.dto.OperatingCostsContent;
import com.mme.mulba.member.service.ExcelService;
import com.mme.mulba.member.service.OperatingCostsService;

@Controller
@RequestMapping("/member")

public class MemberController {
	
	@Autowired
	OperatingCostsService service;
	
	@Autowired
	ExcelService excelService;
	
	@ModelAttribute("cp")
	public String getContextPath(HttpServletRequest request) {
		return request.getContextPath();
	}
	
	@RequestMapping(value = "/excelDown.do")
	public void excelDown(HttpServletResponse response) throws Exception {
        
        excelService.getExcelDown(response);
	}
	
	@RequestMapping("/noticeAdmin")
	public String noticeAdmin(Model model, HttpServletRequest request) {
		
		List<OperatingCostsContent> list = null;
		OperatingCostsContent occ;
		int balance = 0;
		
		list = service.list();
		occ = list.get(list.size()-1);
		balance = occ.getBalance();
		model.addAttribute("list", list);
		model.addAttribute("balance", balance);
		
		return "/member/noticeAdmin";
	}
	
	@RequestMapping("/noticeAdmin_modify")
	public String noticeAdmin_modify(Model model, HttpServletRequest request) {
		return "/member/noticeAdmin_modify";
	}
	
	@RequestMapping("/noticeUser")
	public String noticeUser(Model model, HttpServletRequest request) {
		
		List<OperatingCostsContent> list = null;
		OperatingCostsContent occ;
		int balance = 0;
		
		list = service.list();
		occ = list.get(list.size()-1);
		balance = occ.getBalance();
		model.addAttribute("list", list);
		model.addAttribute("balance", balance);
		
		return "/member/noticeUser";
	}
	
	@RequestMapping("/contentInsert")
	public String contentInsert(Model model, HttpServletRequest request) {
		OperatingCostsContent occ = new OperatingCostsContent();
		OperatingCostsContent tmp;
		List<OperatingCostsContent> list = null;
		
		int income;
		int outcome;
		String str = "";
		
		list = service.list();
		tmp = list.get(list.size()-1);
		
		occ.setRid(tmp.getRid()+1);
		occ.setPrid(tmp.getRid()+1);
		occ.setEvent_date(request.getParameter("cur_date"));
		System.out.println("cur_date : "+request.getParameter("cur_date"));
		occ.setEvent(request.getParameter("event"));
		occ.setContent(request.getParameter("content"));
		
		if(request.getParameter("income")=="") income = 0;
		else {
			str="";
			str = request.getParameter("income");
			str = str.replaceAll(",", "");
			income = Integer.parseInt(str);
		}
		
		if(request.getParameter("outcome")=="") outcome=0;
		else {
			str="";
			str = request.getParameter("outcome");
			str = str.replaceAll(",", "");
			outcome = Integer.parseInt(str);
		}
		//else outcome = Integer.parseInt(request.getParameter("outcome"));
		
		occ.setIncome(income);
		occ.setOutcome(outcome);
		occ.setBalance(tmp.getBalance()+income-outcome);
		occ.setUpdate_date("-");
		
		service.insert(occ);
		
		return "redirect:/member/noticeAdmin";
	}
	
	//모든 항목에서 중요한 것은 맨 처음 튜플이 없을때이다!!!
	//+ 더 해야 할 부분 : 중간의 튜플이 바뀌었을 때, 아래의 것들도 연쇄적으로 수정되는 것
	//+ 더 해야 할 부분 : 아래의 날짜/위의 날짜가 바뀌었을 때 날짜별로 정렬된 후 업데이트, 특히 balance
	//+ 더 해야 할 부분 : prid...
	@RequestMapping("/modify")
	public String modify(Model model, HttpServletRequest request) {
		OperatingCostsContent occ = new OperatingCostsContent();
		occ=service.search(Integer.parseInt(request.getParameter("rid")));
		int balance = occ.getBalance();
		int income = occ.getIncome();
		int outcome = occ.getOutcome();
		balance = balance + outcome - income;
		String str = "";

		//occ.setRid(Integer.parseInt(request.getParameter("rid")));
		occ.setPrid(Integer.parseInt(request.getParameter("prid")));
		occ.setEvent_date(request.getParameter("cur_date"));
		occ.setEvent(request.getParameter("event"));
		occ.setContent(request.getParameter("content"));
		
		if(request.getParameter("income")=="") income = 0;
		else {
			str="";
			str = request.getParameter("income");
			str = str.replaceAll(",", "");
			income = Integer.parseInt(str);
		}
		
		if(request.getParameter("outcome")=="") outcome=0;
		else {
			str="";
			str = request.getParameter("outcome");
			str = str.replaceAll(",", "");
			outcome = Integer.parseInt(str);
		}
		
		occ.setIncome(income);
		occ.setOutcome(outcome);
		occ.setBalance(balance+income-outcome);
		occ.setUpdate_date(request.getParameter("update_date"));
		
		service.update(occ);
		return "redirect:/member/noticeAdmin";
	}

}
