package com.mme.mulba.member.dto;

public class CellStyleColor {

}
